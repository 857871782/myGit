package com.example.the.mytext;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MyActivity extends AppCompatActivity implements View.OnClickListener {

    Button mybtn;
    Button back;
    Button jump;
    Button putD;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_layout);
        mybtn=findViewById(R.id.button);
        mybtn.setOnClickListener(this);
        back=findViewById(R.id.destroy);
        back.setOnClickListener(this);
        jump=findViewById(R.id.Jump);
        jump.setOnClickListener(this);
        putD=findViewById(R.id.putData);
        putD.setOnClickListener(this);
    }
    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.button:
                Toast.makeText(MyActivity.this,"you click button",Toast.LENGTH_LONG).show();
                break;
            case R.id.destroy:
                finish();
                break;
            case R.id.Jump:
                Intent intent=new Intent(MyActivity.this,SecActivity.class);
                //Intent intent=new Intent("android.intent.action.second");
                startActivity(intent);
                break;
            case R.id.putData:
                Intent data=new Intent(MyActivity.this,SecActivity.class);
                String str="Hello Second Activity";
                data.putExtra("Mydata",str);
                startActivityForResult(data,1);
                break;
            default:
                break;
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.main,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.add_item:
                Toast.makeText(MyActivity.this,"You click add",Toast.LENGTH_LONG).show();
                break;
            case R.id.remove_item:
                Toast.makeText(MyActivity.this,"you click remove",Toast.LENGTH_LONG).show();
                break;
        }
        return true;
    }
    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        switch (requestCode){
            case 1:
                if(resultCode==RESULT_OK){
                    String str=data.getStringExtra("data_return");
                    tv=findViewById(R.id.textView2);
                    tv.setText(str);
                }
                break;
            default:
                break;
        }
    }
}
