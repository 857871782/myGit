package com.example.the.mytext;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SecActivity extends AppCompatActivity implements View.OnClickListener {

    Button putback;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sec);
        Intent getDate=getIntent();
        String str=getDate.getStringExtra("Mydata");
        TextView txt=findViewById(R.id.textView);
        txt.setText(str);
        putback=findViewById(R.id.backdate);
        putback.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent intent = new Intent();
        intent.putExtra("data_return","hello,myactivity");
        setResult(RESULT_OK,intent);
        finish();
    }
}
